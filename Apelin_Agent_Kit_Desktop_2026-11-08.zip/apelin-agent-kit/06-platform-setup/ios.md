# iOS Setup

## Context

iOS agent setup is most relevant inside Apelin itself. On jailed/unjailbroken devices, only mobile-privileged operations are available.

## Rules

- Do not assume full root access.
- Do not bypass Apelin's signing and packaging flow.
- Use project-local agent instructions.
- Respect app sandbox and bootstrap paths.
