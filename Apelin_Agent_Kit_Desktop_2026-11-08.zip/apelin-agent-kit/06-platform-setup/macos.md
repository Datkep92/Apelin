# macOS Setup

## Check available tools

```sh
uname -a
command -v git node npm python3 gh codex opencode
printf 'PATH=%s\n' "$PATH"
```

## Notes

- Use zsh Terminal as the default shell.
- Preserve Unix file permissions and executable bits.
- Distinguish Intel versus Apple Silicon when selecting tools.
