# Windows Setup

## Recommended shell

- Use PowerShell for command execution and path-heavy tasks.
- Use Git Bash only when the project requires POSIX shell behavior.
- Quote paths containing spaces with double quotes.

## Check available tools

```powershell
$PSVersionTable
Get-Command git, node, npm, python, gh, codex, opencode -ErrorAction SilentlyContinue
```

## Notes

- Windows path delimiter is backslash; many CLI tools also accept forward slash.
- Environment variables use `$env:NAME` in PowerShell.
- Do not rely on Unix-only commands unless Git Bash is explicitly selected.
- Watch executable permissions and line endings (CRLF vs LF) when importing Apelin files.
