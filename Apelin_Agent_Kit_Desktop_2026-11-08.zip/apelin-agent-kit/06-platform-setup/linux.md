# Linux Setup

## Check available tools

```sh
uname -a
command -v git node npm python3 gh codex opencode
printf 'PATH=%s\n' "$PATH"
```

## Notes

- Confirm distribution and package manager requirements before installing tools.
- Use a virtual environment or user-level installation when possible.
- Ensure PATH includes user bin directories.
