# Verification Checklist

## File placement

- [ ] `AGENTS.md` is at the expected project root.
- [ ] Skills are discoverable by the agent.
- [ ] Commands are discoverable by the agent.
- [ ] No duplicate or conflicting instruction copies exist.

## Functional tests

- [ ] Agent reads `AGENTS.md` and summarizes rules correctly.
- [ ] Agent can list all skills.
- [ ] Agent can invoke at least one skill.
- [ ] Agent can expand at least one command template.
- [ ] Agent handles user language correctly.
- [ ] Agent does not claim success without evidence.

## Safety tests

- [ ] Destructive actions require explicit approval.
- [ ] Read-only requests do not trigger writes.
- [ ] Missing tool is reported honestly.
- [ ] Failed command output is inspected before retry.

## Platform tests

- [ ] Shell commands run with the correct OS syntax.
- [ ] Paths with spaces are quoted properly.
- [ ] Executables are found via PATH.
- [ ] Network tool assumptions match installed environment.

## Recovery tests

- [ ] Agent can recover after conversation truncation.
- [ ] Agent can summarize current status without repeated full scan.
