# Global Load Strategy

For agents with modular skill loading:
- Load `01-apelin-core/AGENTS.md`.
- Load `03-skills/sep-working-rules/`.
- Keep Apelin commands as templates.

For agents without modular skill loading:
- Load `01-apelin-core/AGENTS_PORTABLE_FULL.md` instead of AGENTS.md plus skills.
- This avoids missing the mandatory Sếp rules.

For project-local agents:
- Use `AGENTS.md` at repository root.
- Copy only the skills required by that project's work.
- Keep all custom project rules in `AGENTS.md`.

For global agents:
- Install `AGENTS_PORTABLE_FULL.md` as the global instruction file.
- Add snippets from `03-commands/` to the global command store if supported.

Validation:
- Ask the agent: "Summarize the 10 Sếp rules before answering."
- If it cannot list them, loading is not correct.
