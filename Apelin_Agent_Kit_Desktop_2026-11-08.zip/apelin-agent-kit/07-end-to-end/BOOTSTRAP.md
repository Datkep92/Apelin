# End-to-End Agent Bootstrap

Use this file when the user asks to configure an agent CLI or desktop application to behave like Apelin.

## Phase 1: Inspect existing environment

Run these checks first and save results:

```sh
pwd
printf 'OS: '; uname -a
printf 'Shell: '; printf '%s\n' "$SHELL"
for x in codex opencode dsh node npm python3 git gh; do command -v "$x" || true; done
```

On Windows PowerShell:

```powershell
$PSVersionTable
Get-Command codex,opencode,dsh,node,npm,python,git,gh -ErrorAction SilentlyContinue
```

## Phase 2: Choose scope and placement

Select one of:

1. Project-local agent setup (recommended):
   - Put `AGENTS.md` at repository root.
   - Put `03-skills/` under repository `.agent-skills/` or tool skill folder.
   - Put `04-commands/` as command templates or snippets.

2. Global agent setup:
   - Put core instructions in the agent's global instructions file.
   - Put skills in the agent's global skill folder.
   - Put commands in the agent's global commands folder.

## Phase 3: Install base tools

- Git is required.
- Node.js is required for dsh and optional tools.
- Python 3 is required for helper scripts.
- GitHub CLI is optional but recommended for repository issues/publishing flows.

Do not install a missing tool without telling the user what it is and why it is needed.

## Phase 4: Configure command execution behavior

The desktop agent should mirror Apelin:

- Use `AGENTS.md` as the primary instruction file.
- Use skills as modular instruction units.
- Use commands as reusable prompt templates.
- Prefer targeted file reads and parallel independent checks.
- Avoid broad full-repo edits without prior scan.
- Require explicit user approval for destructive operations.
- Track changed files and summarize verification.

## Phase 5: Register Apelin core instructions

1. Copy `01-apelin-core/AGENTS.md` to the target repository root.
2. If the repository already has its own AGENTS file, merge rather than overwrite:
   - Keep existing repository-specific rules.
   - Append Apelin rules under a clearly named section.
   - Resolve conflicts by choosing stricter rule.
3. Copy `CA_NHAN_HOA.md` when project personalization is needed.
4. Copy `CHECKLIST.md` and `ARCHITECTURE.md` when relevant.

## Phase 6: Register skills

For every folder in `03-skills/`:

- Preserve folder name.
- Ensure skill file is discoverable by the target agent.
- Do not duplicate skill text into AGENTS.md.
- Keep skills modular and lazily loaded.
- Prefer skill names with clear scope.
- Maintain one canonical source per concept.

## Phase 7: Register commands

For every command markdown in `04-commands/`:

- Preserve command name.
- Preserve placeholders such as `{{content}}`.
- Adapt command wrapper format to target agent syntax if necessary.
- Test one command end-to-end after registration.

## Phase 8: Platform specifics

See `06-platform-setup/*.md`.

## Phase 9: Verify

Run all checks in `07-end-to-end/VERIFY.md`.

## Session recovery

If the AI is interrupted:

1. Re-read AGENTS core and active handoff.
2. Inspect git status.
3. Summarize pending items.
4. Restart from the last unfinished step.
