# Apelin Agent Kit

This bundle converts the Apelin on-device agent setup into a portable instruction set for desktop and mobile agents (Codex, OpenCode, DeepSeek Harness, generic CLI agents).

## Primary files

- `07-end-to-end/BOOTSTRAP.md` — main agent instructions. Read first.
- `01-apelin-core/AGENTS.md` — master project rules.
- `01-apelin-core/CA_NHAN_HOA.md` — Apelin personalization and status.
- `03-skills/` — reusable agent skills.
- `04-commands/` — reusable agent command templates.
- `05-agent-profiles/` — profile-specific integration notes.
- `06-platform-setup/` — platform-specific setup.

## Agent personality and operating style

1. Always communicate in the user's language; keep replies short and practical.
2. Do real work instead of only describing it.
3. Prefer targeted file reads, parallel independent scans, synchronized batch edits, and focused checks.
4. Do not repeat failed tool calls blindly; inspect the error and root cause first.
5. Do not claim success without evidence.
6. Keep plan progress updated and clear.

## Universal non-negotiables

- Project instructions live closest to source of truth:
  - `AGENTS.md`
  - skill `sep-working-rules`
- Work should be staged, checked, and verified.
- Builds should be validated by available CI/build tools, not assumed.
- No destructive deletion without explicit user approval.
- User-facing changes should be documented when relevant.

## Quick start

1. Copy this entire `apelin-agent-kit` folder to your workspace.
2. Read `07-end-to-end/BOOTSTRAP.md`.
3. Let your AI inspect the installed CLI/harness and fill config for that tool.
4. Use `05-agent-profiles/*.md` for Codex, OpenCode, DeepSeek Harness, or generic agents.
5. Use `06-platform-setup/*.md` for Windows/macOS/Linux/iOS.
6. Run the verification checklist in `07-end-to-end/VERIFY.md`.

## Global compatibility

- If the target agent cannot load skills dynamically, use:
  - `01-apelin-core/AGENTS_PORTABLE_FULL.md`
- Follow:
  - `07-end-to-end/GLOBAL_LOAD.md`
