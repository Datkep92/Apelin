---
name: viet-command-menu
description: Các cụm lệnh Vietnamese để gọi nhanh luồng phổ biến trong Apelin: trạng thái, đọc/tìm file, kiểm tra CI, fix đồng bộ, đa luồng, khử ngữ cảnh, bảng việc đang dở, và framing build/release/install; ưu tiên targeted reading và batch edit.
---

# Skill: Vietnamese Command Menu (fast path)

## Purpose
Map common Vietnamese requests to concise, fast execution patterns. Use this when the request matches one of the command phrases below. Do not expand scope beyond what is needed.

## Fast defaults
- Prefer targeted reads: `file_find`, `file_grep`, `file_list`, then `file_read`.
- Do not read all files unless necessary.
- Use 2-3 parallel lanes max when request asks parallel.
- Update all affected callers in one batch; never iterate file-by-file.
- Keep responses concise and practical.
- Verify only relevant local checks, not full repo unless request is publish.

## Command mapping
### "trạng thái", "status", "HEAD là gì"
- Run `git status`, report branch, ahead/behind, staged/unstaged, HEAD/tag.
- State one plain sentence: clean/dirty.

### "đọc file X", "xem file X"
- `file_read` with bounded limit (`limit=200`, relevant offset).
- Summarize:
  - purpose
  - key symbols
  - potential risks or likely edit location.
- Avoid full file unless exact file is small.

### "tìm" / "search quickly"
- `file_grep` first then `file_find` as needed.
- Return top relevant sites and grouped by file, not raw grep dump.

### "đọc luồng về topic"
- Use 3 bounded lanes only if no overlap.
- Map entrypoints first (grep symbols), then choose central files.
- Summarize via multi-agent protocol, then direct source checks for conflicts.

### "fix nhanh / fix batch"
- Reconstruct full impact set before editing.
- one coordinated patch across all surfaces:
  - logic
  - caller signatures
  - types/contracts
  - persistence if needed
  - check post conditions.
- report changed and not-tested behavior load/check separately.

### "đa luồng nhanh"
- Use only when ≥3 genuinely independent readonly lanes.
- each lane has `1–3 tight questions only`.
- produce synthesis merge then choose one fix strategy.
- avoid duplicated file reads and variable node count.

### "khử context" / "đọc ít"
- choose one objective.
- build narrow relevant scope file list.
- avoid multi-file traversal of unrelated dirs.
- record outcome to avoid rerunning.

### "bảng việc đang dở" / "status board"
- read CA_NHAN_HOA.md §9 plus handoff.
- summarize only open actions, blockers and next steps.
- avoid reading project everything.

### "kiểm tra CI"
- `gh run list` / API run view latest for HEAD and run status.
- If failing, extract logs after failure markers and name exact likely culprit.
- do not rebuild locally.

### "phát hành" / "release flow"
- Confirm user actually asked.
- version/checklist, CI, tag, release, then compile/SHA verified.
- only with release asked call green.

### "cài app / install"
- Apelin package artifact via `apelin_package_install`.
- dependency only through `irisin-cli install --yes` root as required.
- never apt/dpkg manually.

### "không cần phát hành"
- Explicitly note release track is paused.
- do not invoke CI/tag/publish to avoid unwanted churn.
- keep latest state stable.

## Override rule
When user gives disambiguation such as “fix nhỏ” or “chỉ sửa caller”
- respect scope.
- describe exactly what you did not change.

## Synthesis output contract
For any task:
- What changed
- What verified
- What was only read/not seen
- What was intentionally skipped
- Next optional action shorter.
