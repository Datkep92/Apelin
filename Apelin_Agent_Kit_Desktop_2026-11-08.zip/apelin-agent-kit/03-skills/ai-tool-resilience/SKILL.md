---
name: ai-tool-resilience
description: Dùng trước và trong mọi lượt sử dụng công cụ (file, shell, git, screen, build, browse web) để tự tránh lỗi lặp lại: luôn có reason, đọc tệp lớn theo cửa sổ, không truy cập ngoài project, phân tích lỗi trước khi retry, không retry vô hạn với provider/model/tool không khả dụng. Áp dụng mọi dự án.
---

# AI Tool Discipline — tự tránh lỗi và tự sửa

> Skill cá nhân hoá. Áp dụng mọi dự án, mọi phiên. Đọc trước khi gọi tool hoặc sau khi một tool trả lỗi.

## 1. Mọi call phải có `reason` thật sự
- Mỗi tool call **bắt buộc** `reason`: một cụm ngắn nêu *tại sao* làm bước này, không viết “just in case”.
- Thiếu `reason` ⇒ call bị từ chối và wasted turn. Nếu lên danh sách rồi mới gọi, thêm reason ngay khi plan.

## 2. Đọc tệp lớn theo cửa sổ
- Không đọc toàn bộ tệp > 200 KB một lượt; dùng `offset`/`limit` (file_read trả cửa sổ).
- Nếu cần tổng quan tệp lớn: đọc đầu + cuối, sau đó targeted `grep`/`file_find`, chỉ đọc thêm phần liên quan.
- Log/event có thể rất lớn: chỉ đọc các dòng matching từ khoá, không cat toàn file.

## 3. Tôn trọng ranh giới project
- Chỉ đọc/ghi đường dẫn **bên trong project**.
- Không cố truy cập `/tmp`, `~/Documents/wiki.qaq.apelin` root, project khác nếu tool từ chối. Nếu cần dữ liệu ngoài project, nhờ user/copy có kiểm soát, chép vào project và ghi rõ là dữ liệu tạm.
- Khi working directory là project, mọi path đều tương đối với project root.

## 4. Phân tích lỗi trước khi retry
Khi tool trả `isError:true` hoặc lỗi:
1. Đọc **toàn bộ message** lỗi (không chỉ status).
2. Xác định **nguyên nhân gốc** (sai path, chưa có file, quyền, toolchain, model/provider, UI chưa settle).
3. Chỉ retry **một lần** sau khi sửa đúng tham số.
4. Nếu cùng lỗi lập lại ⇒ dừng, báo user/môi trường, không brute force.

## 5. Không retry vô hạn với tài nguyên không khả dụng
- **Quota/credits/usage limit/model đã retire/upstream unavailable/DB briefly unavailable**: đây là vấn đề người dùng/nhà cung cấp; không retry liên tục; báo rõ và gợi ý hành động (thay model/pack quota/thử lại sau).
- **Toolchain/SDK chưa cài hoặc không dùng được trên thiết bị**: không tự đoán đường dẫn; báo user thiết lập trong Settings.
- **Model Qoder/unknown/disabled**: không tự đặt tên model guessed; dùng model đã có/đã được user chọn.

## 6. Lệnh shell có kiểm chứng trước
- Trước khi chạy lệnh mới, xác định executable tồn tại (`which`/`ls`) và đường dẫn trong repo.
- Dùng argv rõ ràng; không rely vào shell expansion.
- Nếu command thất bại, inspect exit code/stderr; không escalating sang root chỉ để bypass.
- `root` chỉ khi thực sự cần và user đồng ý.

## 7. Thao tác UI có điều kiện
- `screen_read_tree`/`interact`: nếu foreground app chưa settle (lỗi 3s), không spam retry; ổn định UI trước.
- Mỗi hành động UI phải có consent theo mode Apelin; không tự chụp ảnh mà không hỏi.
- Không lạm dụng screenshot nếu UI tree đủ.

## 8. Tool call bị chặn an toàn không coi là bug của ứng dụng
- `outside project`, `missing required property`, `file over size limit` ⇒ tự chỉnh hành vi gọi tool.
- Nếu phải đọc tệp lớn, luôn dùng cửa sổ; nếu tệp cần trọn vẹn, chia nhỏ và ghi note offset tiếp theo.

## 9. Hành vi tự sửa loops
- Sau mỗi lỗi, ghi ngắn vào note/log kế hoạch: lỗi gì, gốc rễ, param đã sửa, kết quả.
- Không để 3+ call thất bại liên tiếp cùng root cause mà không đổi cách.
- Nếu một workflow liên tục fail (git push auth, clone conflict), dừng và đặt câu hỏi cho user thay vì lặp.

## 10. Giao tiếp kết quả
- Báo rõ lỗi đã gặp, đã thử gì, còn gì chưa kiểm chứng.
- Phân biệt “không thể do quota/provider”, “không thể do môi trường”, “đã sửa được ngay” để user không nhầm.
