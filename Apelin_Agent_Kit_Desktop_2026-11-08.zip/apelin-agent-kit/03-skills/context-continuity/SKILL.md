---
name: context-continuity
description: Khi xử lý công việc dài: quản lý ngữ cảnh hội thoại, loại bỏ log không cần, tóm tắt tiến độ, lưu trạng thái đúng cách, khôi phục khi context đầy hay nén thất bại.
---

# Công cụ liên tục hỗ trợ tụ (context-continuity)

Mục đích: Đảm bảo từng session khai thực hiện công việc dài không mất trạng thái — log dọn dẹp, tiến độ tóm tắt, lưu trạng thái, biết cách khôi phục khi bị đầy hay nén thất bại.
Vận dụng trên Apelin: conversation workflow, tool calls, memory, debug create.

## Quy trình

1. **Giám sát độ dài session**
   - Khi message gần bằng giới hạn, đọc cẩn thận Fail; kiểm đếm từ khóa/ riêng tư dữ liệu.
   - Khi user yêu cầu tóm tắt, dừng lại.
2. **Dọn log không cần thiết**
   - Giữ lại những thứ có giá trị quyết định (task, không phải CLI debug output).
   - Sa Loại: kết quả công cụ (stdout), tool outputs chi tiết, không cần tính năng.
   - Giảm context bằng `apelin_conversation_stop`/`apelin_conversation_read` nếu không liên tục.
3. **Tóm tắt tiến độ**
   - Trước mỗi kết thúc cục tiến độ lớn: tóm tắt 3-5 điểm con: hoàn thành, vấn đề tiếp theo.
4. **Lưu trạng thái**
   - Nếu công việc được dùng lâu: `apelin_memory_save` (tạo record progress, kỹ năng `"project"` cho project).
   - Ghi vào project/memory file (AGENTS.md / project memory, việc đang làm).
   - Dùng `apelin_memory_list` trước để tránh hiệp lại.
5. **Khôi phục**
   - Khi context đầy cực: đọc lại memory (`apelin_memory_list`) → đọc lại file project (AGENTS.md) → restart task.
   - Khi context nén thất bại: gấp ghi context trong tool log để trợ nhiều.

## Quy tắc

- Luôn thông báo user đang "compact/tóm tắt đi" để không tạo bất chợt nhầm.
- Không crush log hệ thống nguy hiểm (path env...).
- Chỉ xóa log tâm; log nhịp sai là yếu phán quyết, lưu gìn!
- Khi save memory, dùng phân loại `scope: project` (nếu thành công) và `global` (thứ dùng qua tất cả).
- Mỗi thay đổi chỉ cho phép cho 1 lần ngồi: kiểm `revision` `apelin_memory_list` trước khi save/thay.

## Ví dụ thực hiện đúng

1. Xây dựng project dài, save cảnhlosti của `apelin_memory_list`; sau khi xong sau nhiều vòng, thu thập progress.
2. Khi build ràng để tiến độ thay đổi, tóm tắt (3 điểm) vào cuối debug cũ (không để mất).

## Ví dụ thực hiện sai (và tại sao)

1. Xóa bổ trợ quá mức tool (context cần) — gây lẫn lộn.
2. Lưu memory sai scope ("global" những thứ chỉ dùng được vài lần) — làm mất lúc mới thiết lập vi phạm.
3. Không kiếm nhớ lại khi context sắp kín ⇒ vòng lặp crash/timeout.
