---
name: ca-nhan-hoa-apelin
description: Dùng khi người dùng hỏi về Apelin bản cá nhân hoá (repo fork Datkep92/Apelin): muốn thêm/chỉnh chức năng mới cho Apelin, build, CI, đóng gói, cài lên máy, phát hành, đổi cấu trúc, hoặc thêm cá nhân hoá/bản vá (fix). Đọc skill này trước khi trả lời hoặc sửa code.
---

# Apelin bản cá nhân hoá — cấu trúc & quy trình build

Tài liệu sống của fork nằm trong repo, **bắt buộc đọc trước khi làm**:
- `CA_NHAN_HOA.md` (đầu repo) — quy tắc cá nhân hoá, quy trình build đầy đủ, và
  **mục 6.1 là nhật ký sống**: mỗi chức năng mới / bản vá phải thêm 1 dòng
  (Ngày | Loại | Tóm tắt | Hash commit | Yêu cầu giữ lại), commit kèm code.
- `AGENTS.md` (đầu repo, mục cuối "Fork personalisation") — bản rút gọn các
  quy tắc này; phần còn lại của AGENTS.md là quy tắc gốc của upstream.

## 1. Repo ở đâu

`/var/mobile/Documents/wiki.qaq.apelin/Projects/Apelin`
- Nằm **ngoài root dự án đang chat** → công cụ file/git của Apelin bị từ chối;
  mọi thao tác qua `shell_run` (git qua shell chỉ để đọc/commit/push theo
  quy tắc bên dưới).
- remote: `origin` = `https://github.com/Datkep92/Apelin.git` (bản thật),
  `upstream` = `https://github.com/owngoal-dev/Apelin.git` (gốc).
- Nếu folder mất: `git clone https://github.com/Datkep92/Apelin.git <đường dẫn>`
  rồi `git remote add upstream https://github.com/owngoal-dev/Apelin.git` và
  `git config user.name "Lakr233"`, `git config user.email "git@qaq.wiki"`
  (repo mới không có identity). Mã nguồn không bao giờ mất vì đã push.

## 2. Cấu trúc repo (tóm tắt)

| Mục | Vai trò |
| --- | --- |
| `Apelin/` | App giao diện UIKit (sidebar dự án, chat Composer, cài đặt; `Application/LegacyHome.swift` là màn hình chính) |
| `Apelind/` | Daemon quyền cao: chủ phiên hội thoại, gọi tool, chính sách cho phép |
| `Packages/ApelinAgent/` | Bộ não agent: prompt/ngữ cảnh/công cụ; `ApelinAgentWorker` chạy trong worker |
| `Extensions/`, `Workers/`, `Shared/`, `Widgets/` | Công cụ mở rộng, tiến trình phụ, mã chung, widget |
| `Scripts/` | Kiểm tra & đóng gói (`check-*.py`, `check-checklist.sh`, `package-deb.sh`) |
| `Configuration/` (Version.xcconfig), `Packaging/`, `Tests/`, `Documents/` | Version, kế hoạch gói .deb, test, tài liệu |
| `Makefile` | `deb`, `check`, `harness`, `set-version` (xem `make help`) |
| `CHECKLIST.md` | Danh mục quyết định; `make check` chạy mục này đầu tiên |
| `AGENTS.md` | Quy tắc cho agent đọc repo (có mục fork ở cuối) |
| `.github/workflows/` | `ci.yml` (push vào main), `release.yml` (tag `v...`), `sync-upstream.yml` (chạy tay), `pages.yml` |

## 3. Quy trình thêm chức năng rồi build

1. **Base = upstream mới nhất:** `git fetch upstream main` → `git merge upstream/main`.
   Không fetch/push tag upstream. Conflict thì giữ cá nhân hoá của fork
   (`ModelProvidersController.swift`, `Localizable.xcstrings`; mẫu: commit `0428636`).
2. **Code + commit** từng ý, tiêu đề tiếng Anh nêu rõ hành động.
3. **Thêm 1 dòng vào mục 6.1 của `CA_NHAN_HOA.md`** rồi commit cùng push.
4. **Push** (công cụ push của Apelin không tới repo ngoài dự án):
   ```sh
   export TMPDIR=/tmp
   TOK=$(gh auth token); B64=$(printf "x-access-token:%s" "$TOK" | base64 | tr -d "\n")
   git -c "http.extraHeader=Authorization: Basic $B64" push origin main
   ```
5. **Build bằng CI** (máy không có `xcodebuild`, không build trên máy):
   ```sh
   gh run list -R Datkep92/Apelin                 # ~20–27 phút, 2 run song song
   gh run watch <run id> -R Datkep92/Apelin       # hay poll: gh api repos/Datkep92/Apelin/actions/runs/<id> --jq .status
   ```
   artifact tên `apelin-<full sha>` (repo cũng có `SHA256SUMS`).
6. **Tải về:** `TMPDIR=/tmp gh run download <run id> -R Datkep92/Apelin -n apelin-<sha> -D /tmp/apelin-art`
   → chỉ lấy `.deb` **`iphoneos-arm64`** (máy này arm64, không arm64e), copy bản chính vào `Downloads`.
7. **Cài** (shell_run `root: true`; nhà cài **không** chạy maintainer script —
   không bao giờ để `postinst` chạy vì nó bootout `apelind` và giết phiên chat):
   ```sh
   icli pkg install <đường dẫn .deb>          # chỉ báo scripts, không chạy
   icli app kill wiki.qaq.apelin --force       # rồi
   icli app launch wiki.qaq.apelin
   ```
   Không restart `apelind` khi chưa có đồng ý của người dùng.
8. **Phát hành** (chỉ khi người dùng yêu cầu): `make set-version VERSION=x.y.z-fork1`
   nếu cần tách version, rồi `gh release create "v<version>-<sha>" <deb> --title ... --notes ...`
   — tag của riêng fork, KHÔNG lấy tag official.
9. Publish lên kho của người dùng (`apelin_package_publish`) cũng chỉ khi được yêu cầu.

## 4. Kiểm tra sau thay đổi (trên máy, không cần Mac)

```sh
python3 Scripts/check-accessibility.py Apelin
sh Scripts/check-checklist.sh CHECKLIST.md
python3 Scripts/check-stale-strings.py "Apelin Widgets"
python3 Scripts/check-format-strings.py "Apelin Widgets"
python3 Scripts/check-catalog-keys.py          # khi sửa Localizable.xcstrings
```
- `check-translations.py` **không bao giờ pass** trên máy này (thiếu `plutil`) — không coi là lỗi.
- Kiểm tra giao diện bằng accessibility tree (`apelin_screen_read_tree` /
  `icli ui tree|at|tap`); **`icli screen ocr` và `icli screen describe` hỏng**.
- Chưa thấy chạy thật trên máy thì nói rõ "chưa kiểm chứng", không nói đã xong.

## 5. Bẫy máy này

- Mọi lệnh `gh` cần `TMPDIR=/tmp`, không thì gh hỏng.
- Shell mặc định `dash`, không có `/bin/sh` cho git helper của gh → bọc `bash -c`.
- Makefile là lệnh macOS (cần `xcrun`), trên máy thiếu → chỉ CI build được.
- Không force push, không đổi URL remote, không tự làm `.deb` bằng tay
  (`dpkg-deb`/`ar`/`tar` ngoài CI).
- Định danh bất di bất dịch: package id `wiki.qaq.apelin`, bundle id, projectID.

## 6. Cá nhân hoá đang có (phải sống sót sau mọi lần merge upstream)

1. Một nhà cung cấp có **nhiều cấu hình**, mỗi cấu hình một khoá API riêng +
   dải model riêng, chọn model trong sheet có tìm kiếm (`c186bec`…`1c49e95`).
2. Hấp thụ upstream `v0.1.8..v0.3.0` + workflow `sync-upstream.yml` (`0428636`).
3. Bản vá **data-home**: dữ liệu nằm ở `~/Documents/wiki.qaq.apelin` thay vì
   container iOS, import hộ `DataFolder` (`dfe14b9`, `ee4fc4a`, `ec2727a`).
4. Bản vá hiển thị **danh sách dự án** (Home và bộ chọn dự án phải cùng số dự án).

Bất kỳ chức năng/bản vá mới nào cũng phải bổ sung một dòng tương ứng vào
mục 6.1 của `CA_NHAN_HOA.md`. Dòng nào trong bảng bị thiếu khi build lại =
làm sai quy trình.
