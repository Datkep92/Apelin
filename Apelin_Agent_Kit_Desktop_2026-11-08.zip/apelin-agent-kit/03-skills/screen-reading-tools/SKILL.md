---
name: screen-reading-tools
description: Khi AI không thể xem ảnh trực tiếp: đọc màn hình/ảnh bằng công cụ (UI tree, OCR, tesseract) thay vì nói không đọc được. Dùng khi cần mô tả nội dung màn hình, ảnh chụp, hoặc giao diện app.
---

# Đọc màn hình/ảnh bằng công cụ (khi AI không nhìn được ảnh)

## Khi nào dùng
- Bạn (AI) **không thể xem ảnh trực tiếp** (mô hình không hỗ trợ vision) nhưng cần mô tả nội dung màn hình, ảnh chụp, hoặc giao diện app.
- Người dùng hỏi "đọc màn hình", "mô tả ảnh", "xem màn hình đang hiện gì".
- **Không** nói "không đọc được" — luôn thử công cụ trước.

## Thứ tự ưu tiên (nhanh → chậm)

### 1. UI tree (chính xác nhất cho giao diện app)
- `apelin_screen_read_tree` — đọc cấu trúc app: nút, chữ, vị trí, role.
- Dùng `match`, `clickable_only`, `max_elements` để lọc nếu màn hình lớn.
- Kết quả có `elementsTotal`/`elementsMatched` → biết mình đang thấy bao nhiêu.
- **Ưu điểm**: chính xác, có vị trí, phân biệt button/text.
- **Hạn chế**: chỉ app expose UI tree; không đọc được chữ trong ảnh thường.

### 2. Screenshot + OCR (cho ảnh thường hoặc app không expose tree)
- Chụp ảnh: `apelin_screen_capture` (Apelin) hoặc `icli screen shot` (lưu file).
- OCR bằng **tesseract** trực tiếp trên file ảnh:
  ```
  tesseract <đường_dẫn_ảnh> stdout -l eng+vie
  ```
  (thêm `vie` cho tiếng Việt; `eng` cho tiếng Anh; có thể kết hợp `eng+vie`).
- `icli screen ocr` / `icli screen describe` cũng có nhưng **thường lỗi chụp nội bộ** → fallback sang tesseract trên file từ `icli screen shot`.

### 3. Kết hợp
- UI tree cho bố cục + OCR cho chữ trong ảnh → mô tả đầy đủ.

## Quy trình chuẩn

1. **Xin đồng ý chụp ảnh** (screenshot captures whatever is on screen, including other apps) — một ảnh = một lần đồng ý. Hỏi rõ trước khi chụp.
2. Đọc UI tree trước (không cần ảnh, nhanh).
3. Nếu cần "nhìn" ảnh (màu, bố cục, icon, chữ trong ảnh): chụp → OCR bằng tesseract.
4. Mô tả cho người dùng: chữ, nút, vị trí, trạng thái. Nói rõ phần nào từ UI tree, phần nào từ OCR.

## Lưu ý quan trọng
- **Không đoán** nội dung màn hình — phải đọc bằng tool.
- Nếu tool lỗi (vd. `icli screen ocr` báo "OCR screenshot failed"), **thử tesseract trực tiếp** trên file từ `icli screen shot`, không bỏ cuộc.
- Tesseract cần ngôn ngữ phù hợp (`-l vie` cho tiếng Việt). Kiểm tra `tesseract --list-langs`.
- Ảnh chụp từ `icli screen shot` lưu ở `/var/tmp/icli-*.jpg` (đường dẫn trả về trong kết quả).
- Khi Ask Before Using Screen bật: phải xin đồng ý đọc/chụp trước, từng bước.
- Một ảnh chụp = một lần đồng ý; không tái sử dụng ảnh cũ cho mục đích khác.

## Ví dụ lệnh

```sh
# Chụp màn hình
icli screen shot
# → trả về path file

# OCR tiếng Việt + tiếng Anh
tesseract /path/to/icli-XXXX.jpg stdout -l eng+vie

# Kiểm tra ngôn ngữ tesseract có
tesseract --list-langs
```

## Khi không thể đọc
Chỉ nói "không đọc được" khi **đã thử** UI tree + OCR/tesseract và đều thất bại, và nêu lý do cụ thể (app không expose tree, OCR không nhận dạng được, ảnh mờ, v.v.). Luôn đề xuất bước tiếp theo.
