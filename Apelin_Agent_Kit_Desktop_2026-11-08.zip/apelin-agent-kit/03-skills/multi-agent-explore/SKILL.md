---
name: multi-agent-explore
description: Khi cần đọc nhiều file/chức năng, dùng nhiều agent song song để quét các phần không overlap, tổng hợp rồi mới sửa cùng một batch, kiểm tra đồng bộ toàn luồng; không sửa từng file liên tiếp và không đọc toàn dự án nếu grep/class/entrypoint đã đủ.
---

# Skill: Fast Parallel Exploration and Synchronized Change

## Purpose
Use parallel analysis only when it speeds delivery without losing accuracy. Parallel agents are coordination tools, not a replacement for source-level verification. One coordinator owns synthesis, all edits, and final claims.

## Operating preference - Speed + Accuracy
The user values fast, accurate, high-leverage work:
- Maximize capability in every request.
- Avoid repetitive edit-read-fix loops.
- Prefer fast parallel discovery and one synchronized batch change.
- Do not over-analyze files unrelated to the active request.
- Deliver complete, consistent behavior rather than partial updates.

## When to use
- The task has 3+ independent reading/analysis slices.
- Each slice has clear file, component, or question boundaries.
- Source files are large enough that serial reading wastes time.
- The task is exploratory, diagnostic, or documentation-oriented.
- Multiple related logic areas must be identified before a coherent change.
- Runtime behavior must be verified after one synchronized edit.

## Do not use
- For a single root bug that needs one maintained chain of evidence.
- When slices require writes or shared state changes.
- When file ownership cannot be separated.
- When the final answer depends on one unresolved detail.
- When one focused serial trace is clearly faster.
- When parallel output would create more merge noise than insight.

## Workflow - READ FAST THEN CHANGE SYNC
### 1. Define the exact question
State one sentence. Do not start broad reading before that.

### 2. Discover before reading everything
Use:
- file_list and file_find to locate candidate owners.
- file_grep for concrete symbols, function names, error strings, call sites, and invariants.
- Read small structural sections first: imports, declarations, entry points, public API.
- Skip full files when maps are enough.
- Expand only to truly central files.

### 3. Parallel read scopes
Create 3+ non-overlapping scopes only when independent:
- startup / app lifecycle
- chat or session lifecycle
- project catalog / file persistence
- transfer, protected files, attachment
- settings / preference bundle
- package / build / install

Assign each agent one owner scope and a short schema. Keep a read registry of file + function/line + owner + status.

### 4. Deduplicate and synthesize correctly
Before acting:
- remove duplicate hotspot claims
- separate observations from hypotheses
- label confidence high/medium/low
- list unread areas that could change the conclusion
- identify cross-file invariants

### 5. Change in one synchronized batch
When the root cause and impact set are known:
- edit all affected files in one batch
- keep naming, state, serialization, notification, persistence, and UI self-consistent
- do not change scattered pieces hoping later iterations will align them
- preserve existing unchanged behavior outside the target defect
- update related truth sources together: types, manifests, config, checks if relevant

### 6. Verify exactly what the change can prove
Run all relevant local checks:
- make/check scripts if available
- script-level and host tests
- repository checks
- targeted toolchain/self tests when relevant

On-device behavior is only "working" if actually observed.
Unverified behavior belongs under Not tested.

### 7. Record state
After meaningful result:
- update project handoff if active asks for it
- update docs if required by project rule
- mention confirmed vs unverified areas explicitly in final response
- explain what was not done rather than hiding it

## Coordinator protocol
1. Define the exact question in one sentence.
2. Split into non-overlapping read scopes.
3. Assign each agent exactly one scope and one output schema.
4. Keep a read registry.
5. Deduplicate and resolve conflicts before changing.
6. Verify surprising or decision-critical claims from source.
7. Produce one merged conclusion.
8. Make one coordinated batch change.
9. Run consistency and regression checks.

## Task decomposition
Prefer slices by owner, not vague topics.
Good:
- app home: DataFolder, CanonicalPath, LegacyHome.
- chat loading: ChatRuntime, ChatStore, transcript cache.
- project watching: ProjectSummary, ProjectCatalogMonitor, ProjectServiceConfigStore.

Bad:
- "Find issues."
- "Read everything."
- "Fix all affected."

## Ownership rules
- One agent owns a file or directory subset at a time.
- Other agents may consult it, but not overwrite findings.
- Use narrower boundaries when overlap is needed.
- No agent declares another agent wrong without direct source evidence.
- Coordinator has final synthesis and final edit authority within user scope.

## Evidence schema
Each agent returns:
- Scope read.
- High-confidence observations.
- Proposed interpretation.
- Risks or assumptions.
- Open questions.
- Files/areas not read but possibly relevant.
- Function or line references preferred.

## Anti-duplication protocol
- Stop agents if their scope drifts.
- reject duplicate findings unless they add context.
- treat "same file different angle" as one chain.
- mark when evidence is redundant.
- stop reading once essential cross-file invariants are mapped.

## Speed strategy
- grep/read focused symbols, not giant files
- Use file_find/file_list before full read.
- Read central types, entrypoints, producers, consumers.
- Use bounded output.
- Run checks early.
- Avoid rereading main chain repeatedly.
- Schedule independent checks together.
- Ask user only when risk/permission requires it, not for routine next step.

## Accuracy strategy
- Trace root path before proposing.
- Check canonicalization/invariants.
- Treat device and CI evidence as stronger than assumptions.
- Label confidence.
- Mark not-tested behavior clearly.
- Never claim compile/runtime if evidence unavailable.
- Never mark task done when any main behavior is unverified.

## Multi-file consistency rules
When editing, inspect impact clusters:
- model / state transitions
- persistence and decoding compatibility
- follow / attach / reconciliation
- canonical paths and file policy
- project/home/install policy
- migration
- logging
- caches
- UI accessibility labels
- build/checklist requirements

A code change is acceptable only if all impacted clusters remain coherent after edit.

## Synchronized fix rule
Do not perform micro-fix loops:
1. find all relevant call sites and incompatible definitions.
2. decide one corrected topology.
3. patch all impacted spots together.
4. run relevant local checks plus consistency searches.
5. only then report complete.

## Conflict handling
When agents disagree:
1. identify exact code/data supporting each claim.
2. re-read minimal conflicting code only.
3. label unresolved points explicitly.
4. prefer source evidence over consensus.
5. never hide disagreement.

## Synthesis format
- Question answered.
- high-confidence findings.
- key files/functions.
- proposed changes.
- consistency impact.
- verification run and result.
- unresolved gaps.

## Safety
- never parallelize writes.
- never publish, release, install without explicit permission.
- never treat summaries as proof.
- preserve user requested constraints over generic cleanup.

## Effective quick template
"Read only [paths]. Answer [1-3 tight questions]. Return under 300 words. Be parallel? yes/no. Do not modify. Do not touch [reserved path]."

## Bad case heuristic
If discussion duplication >20%, reduce agents and merge.
If one conversation or file trace owns the whole issue, do serial.
If scope boundaries become muddy, stop parallel work.
