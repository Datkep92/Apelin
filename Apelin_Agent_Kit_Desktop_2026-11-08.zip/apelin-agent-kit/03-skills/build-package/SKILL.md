---
name: build-package
description: Khi build và kiểm tra sản phẩm iOS DEB rootless: tối ưu thời gian build, tái sử dụng cache hợp lệ, kiểm tra artifact, tránh build lại — không tự phát hành hoặc cài đặt khi chưa được cho phép.
---

# Công cụ build & đóng gói (build-package)

Mục đích: Build iOS DEB (rootless/iphoneos-arm64) an toàn, tối ưu, artifact được kiểm. Không phát hành hay cài đặt khi chưa có đồng ý.
Vận dụng trên Apelin: build qua CI (máy không có xcodebuild), artifact `apelin-<sha>`.

## Quy trình

1. **Xác định build cần**
   - Kiểm thông tin `apelin_project_build`: package, bootstrap, config (Release/Debug), architecture (iphoneos-arm64 cho rootless, arm64e cho roothide).
   - Nếu thông tin mở rộng: hỏi user đăng ký thiết lập (build ID, environment).
   - Không xác định lại đối với cache giữ trước từ cùng commit (tránh: version không được cập nhật).
2. **Trigger build**
   - Dùng CI GitHub (D…I). `apelin_project_build` nếu có môi trường tại chỗ (chọn `bootstrap` = `rootless` hoặc `roothide`).
   - Tùy biến: `configuration=Release`, `bootstrap=roothide|rootless`; sau đó build twofn có thể nhiều build.
3. **Kiểm cuối**
   - Kiểm SUM: thu thập `hash` (sha256) file .deb từ artifact và so sánh SHA256SUMS (Verify against release checksums).
   - Kiểm biểu đồ (dpkg/deb file install not without agreement).
4. **Xác nhận artifact & licences** (check license checks pass)
5. **Xác nhận chính xác: không gửi lại khi chưa có sự cho phép** (publish/install require explicit user action/call).

## Quy tắc

- Build dựa không thể set bất kỳ credential nào (token/permissions), độc lập từ terminal `gh` (npm/vcs).
- Chỉ build khi code commit ổn định, môi trường toolchain/SDK đang ổn.
- Không cài đặt/staging, cài đặt/copy .deb chỉ có thể user tăng `icli pkg install` hoặc `apelin_package_install`, lúc "root: true" cần.
- Sau khi build, chỉ report hash & location.

## Ví dụ thực hiện đúng

1. Khi kiểm lại "make check" thì setup lại CI `gh run watch` result to verify artifact: hash của `wiki.qaq.apelin_0.3.2_iphoneos-arm64.deb` = `9f4c1560872c9746d5f6033d1e3b9f605bb40a38fb57f85557725121e5635229` khớp SHA256SUMS ở Releases.
2. Sau khi tùy chỉnh xong (`make set-version VERSION=0.3.2`) → submit CI → download artifact → `cp to Downloads`.

## Ví dụ thực hiện sai (và tại sao)

1. Tự tạo .deb bằng `dpkg-deb` local — file vòng để build Apelin đây (với `dpkg-deb -b` ngoài CI) → **lỗi**: Apelin-Build path skip.
2. Dùng CI config sai (rd, version đồng push vào chính).
3. Không SHA256 trước khi cài đặt — file corrupt không thể mưu tính.
