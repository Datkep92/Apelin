---
name: code-change-discipline
description: Dùng khi sửa lỗi, thêm/chỉnh chức năng, hoặc vừa thay đổi mã nguồn (mọi dự án): tìm đúng gốc rễ qua log/crash/code, thiết kế trọn luồng giao diện → logic → lưu trữ → kiểm thử, commit nhỏ, chạy kiểm tra hồi quy (Scripts/ + test cũ), thử thật trên máy, rồi cập nhật tài liệu dự án. Bản gộp của fix-root-cause, complete-feature, regression-guard.
---

# Kỷ luật thay đổi mã (code-change-discipline)

Bản gộp của ba kỹ năng cũ: **fix-root-cause** (tìm đúng gốc rễ), **complete-feature** (làm trọn tính năng), **regression-guard** (chặn lỗi phát sinh).

Mục đích: mỗi lần chạm vào mã nguồn — dù là sửa lỗi hay thêm chức năng — kết quả phải là **chạy thật được, không phá cái cũ, và người sau đọc hiểu được**. Không vá tạm, không đoán, không bỏ dở nửa đường.

Vận dụng trên Apelin: app UIKit, tweak Objective-C, Preferences, daemon, CI build; các script trong `Scripts/` phải chạy mỗi lần.

---

## Fast-scout (tối ưu tốc độ, vẫn chính xác)
- **Trước khi đọc file**: dùng `file_find`/`file_grep` để khoanh vùng symbol/đường dẫn; chỉ `file_read` đúng đoạn (offset/limit) liên quan.
- **Không đọc toàn file** nếu không cần; nếu file lớn, đọc theo cửa sổ 64KB.
- **Xác định phạm vi ảnh hưởng nhỏ nhất**: chỉ sửa file liên quan; không chạm file khác.
- **Kiểm thử targeted**: chạy test/script liên quan, không rebuild toàn bộ.
- **Rollback nhanh**: hash/file trước khi sửa; revert nếu sai.

---

## Quy trình 8 bước

### 1. Đọc cái đang có (trước khi code)
- Đọc `AGENTS.md`, `CHECKLIST.md`; nếu dự án có thì đọc thêm tài liệu trạng thái (`Documents/Guides/README.md`, `00-status.md`, hoặc `ARCHITECTURE.md`).
- Đọc code liên quan bằng `file_read` / `file_grep` / `file_find` — không đoán nội dung file.
- Nếu là repo Datkep92/Apelin thì đọc thêm `ca-nhan-hoa-apelin`.
- Mục nào trong `CHECKLIST.md` chưa tick thì phải xử lý trước khi thêm code mới.

### 2. Dừng lại, thu thập dấu vết (khi là lỗi — trước khi sửa bất cứ dòng nào)
- Log thiết bị: `apelin_log_read` (theo process hoặc subsystem).
- Nếu crash/treo: `apelin_crash_list` → `apelin_crash_read` → `apelin_crash_symbolicate` (đối chiếu dSYM của đúng bản build vừa cài).
- Trạng thái máy: `apelin_package_list`, `apelin_toolchain_list`, `apelin_sdk_list`.
- Không xoá log dự phòng — log là bằng chứng.

### 3. Xác định phạm vi ảnh hưởng
- `git_diff` / `git_status` xem file nào vừa sửa; `git log` xem commit gần nhất.
- Khoanh vùng dễ vỡ: preferences, chuỗi dịch, sidebar, danh sách model, đường dẫn bootstrap, entitlements.

### 4. Truy ngược tới gốc rễ (không mò theo cảm tính)
- Đi theo chuỗi: **lỗi → log → hàm lỗi → call chain → file gốc**.
- Kiểm đường dẫn theo `apelin-bootstrap-paths` (rootless: `@PREFIX@` / `@ROOTFS@`), entitlements theo `apelin-device-executables`, bộ lọc bundle của tweak.
- Không kết luận kiểu "chắc là do…" — phải tái hiện được lỗi trước khi coi là hiểu nó.

### 5. Thiết kế trọn luồng rồi mới code
- **Giao diện**: nút chỉ có icon phải có `accessibilityLabel`; view/cell tự gắn nhãn phải có `isAccessibilityElement`; chuỗi hiển thị dùng `String.LocalizationValue` (không `NSLocalizedString`).
- **Logic**: luồng xử lý rõ, có xử lý lỗi; không để lại nhánh dở.
- **Lưu trữ**: đường lưu và đường đọc khớp nhau (UserDefaults, file cấu hình, tệp dữ liệu…).
- **Kiểm thử**: viết test đơn vị nếu được; chuẩn bị sẵn kịch bản thử trên thiết bị.
- Sửa file gốc, không bypass; thêm một dòng chú thích nếu đoạn code khó hiểu.

### 6. Commit nhỏ, rõ nghĩa
- Mỗi ý một commit, message tiếng Anh mô tả hành động; không gộp nhiều chức năng vào một commit lớn.
- Không commit khi script kiểm tra còn đỏ.
- Cập nhật tài liệu cùng lúc với code (xem bước 8).

### 7. Kiểm tra hồi quy rồi mới coi là xong
- Chạy các script kiểm trong `Scripts/`:
  - `check-accessibility.py` — cell/nút thiếu nhãn là lỗi.
  - `check-checklist.sh CHECKLIST.md` — mục chưa tick là lỗi.
  - `check-stale-strings.py`, `check-format-strings.py`, `check-catalog-keys.py`.
  - `check-translations.py` — chỉ chạy khi máy có `plutil`; thiếu `plutil` không tính là lỗi.
  - `check-shell-deletes.py`, `check-system-only.py` khi có đụng tới shell/worker.
- Chạy lại test cũ liên quan + test mới; máy thật hơn simulator.
- Build lại (`apelin_project_build`) và khi cần thì cài để thử: `apelin_package_install`.
- Báo cáo rõ từng mục **đạt/không đạt**, và tách bạch "đã kiểm chứng trên máy" với "chưa kiểm chứng".

### 8. Kiểm giao diện thật & cập nhật tài liệu
- `apelin_screen_read_tree` vùng vừa sửa → `apelin_screen_interact` (tap/swipe/type) → đọc lại cây giao diện. Cần nhìn màu sắc/bố cục thì xin phép chụp ảnh màn hình trước.
- Chưa từng chạy thật thì phải ghi rõ **"chưa kiểm chứng trên máy"**, kèm cách người dùng tự kiểm.
- Cập nhật nhật ký dự án: `CA_NHAN_HOA.md` mục 6.1 thêm một dòng (Ngày | Loại | Tóm tắt | Hash commit), và cập nhật handoff log.
- Nếu phát sinh loại việc lặp lại nhiều lần thì cân nhắc tạo kỹ năng riêng.

---

## Quy tắc cứng

- **Không đoán**: phải tái hiện được lỗi, hoặc chỉ rõ bằng chứng, trước khi kết luận.
- **Không sửa tính năng khác** ngoài phạm vi lỗi/yêu cầu.
- **Không bỏ sót chức năng cũ**: kiểm cái cũ trước khi sửa cái mới.
- **Không xoá test hay script** vì thấy phiền; hết giá trị thì qua review mới bỏ.
- **Không "chạy test cho có"**: luôn có kết quả cụ thể (số bài đạt/không đạt, file kết quả).
- **Không lưu bí mật** (API key, mật khẩu, khoá riêng) vào ghi chú hay code.
- **Không force push**, không đổi URL remote, không tự phát hành hay cài đặt khi chưa được cho phép.
- Khi sửa xong phải chạy lại `check-accessibility.py` và `check-checklist.sh`.

---

## Ví dụ làm đúng

1. **Crash sau khi cài tweak**: lấy crash report → symbolicate → thấy hàm truy cập quá giới hạn mảng → sửa đúng file gốc → build lại → thử trên máy → hết crash.
2. **Tweak không nạp trên rootless**: kiểm `apelin-bootstrap-paths` và bộ lọc bundle → sửa đường dẫn `@PREFIX@/` → xác nhận đã nạp qua log.
3. **Sửa sidebar**: chạy `check-accessibility.py` + `check-checklist.sh` + thử giao diện → đạt → commit.
4. **Sửa `Localizable.xcstrings`**: chạy `check-stale-strings.py` + `check-format-strings.py` → đạt → commit.
5. **Thêm nhà cung cấp model mới**: sửa `ModelProvidersController.swift` → thêm bundle ID + bộ chọn model → commit → build → thử thật trên máy.

## Ví dụ làm sai (và vì sao)

1. Sửa vài dòng theo suy đoán cho "chắc là chạy" → không rõ gốc, lỗi quay lại.
2. Xoá log cho sạch → mất dấu vết, lần sau mò lại từ đầu.
3. Báo "OK" nhưng chỉ thử trên simulator, chưa chạy máy thật.
4. Build xanh rồi khoe "đã xong" mà không chạy script kiểm → lỗi ẩn tích lại.
5. Bỏ qua crash report người dùng gửi → không sửa được đúng cái đang cháy.
6. Gộp nhiều chức năng vào một commit lớn, message mơ hồ → người sau đọc không hiểu, gỡ lỗi rất chậm.
7. Thêm màn hình mới nhưng để dở phần xử lý/lưu trữ → người dùng chạm vào là lỗi.
8. Sửa đúng nhưng quên nhãn Accessibility → VoiceOver không đọc được, người khiếm thị không dùng được.
