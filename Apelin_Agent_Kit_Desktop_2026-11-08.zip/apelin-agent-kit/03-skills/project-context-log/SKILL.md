---
name: project-context-log
description: Use in every project before and during work: read status/architecture docs first and update project handoff log after changes so any later developer or agent understands current state.
---

# Project Context Handoff Log

Apply this skill to **every** project at the beginning of any substantive work and whenever work stops/pivots.

## Before touching code
1. Locate and read (if present), in order:
   - `Documents/Guides/00-status.md`
   - `Documents/Guides/README.md`
   - `ARCHITECTURE.md` or `README.md`
   - `AGENTS.md`
2. Note the current task, branch, and any blocker from the status log.
3. If docs are missing, start a minimal status log yourself (`Documents/Guides/00-status.md`) with current context.

## During work
- After each logical change:
  - add what was done,
  - what is currently in progress,
  - what remains,
  - verification status and commit hash,
  - blocker or missing test.
- Keep old log entries; append rather than overwrite.

## Commit discipline
- Commit documentation updates in the same logical change as code (for source projects).
- Do not publish/build only docs unless explicitly requested.

## Output emphasis
- Briefly tell the user what you learned from the log and what comes next.
- If a prerequisite is absent (missing docs, missing context), say one-line fallback plan.
