---
name: proactive-tool-discovery
description: Dùng khi tác vụ cần một khả năng/công cụ chưa rõ đã có hay chưa, hoặc khi model đang có nguy cơ trả lời "không có khả năng". AI phải chủ động kiểm inventory, khám phá công cụ/b package, tự viết helper nhỏ nếu cần, thay vì dừng than vẫn thiếu khả năng. Áp dụng mọi dự án.
---

# Phát sinh khả năng chủ động

## 1) Không answering "không có khả năng" trước khi điều tra
- Mặc định coi "không có" là **chưa kiểm**, không phải sự thật.
- Trước khi từ chối, phải kiểm tra ít nhất các bước sau theo ngữ cảnh:
  - `which`, `command -v`, `PATH` thực tế đang có (mobile)
  - công cụ của Apelin đã đăng ký (`apelin_toolchain_list`, `apelin_sdk_list`)
  - `icli probe` / tài liệu SDK để tìm API/công cụ có thể gọi
  - các gói đã cài có thể cung cấp công cụ (`irisin-cli` làm root khi cần)
  - ngôn ngữ/runtime có sẵn trên thiết bị (shell, Python 3, Perl, Node; C/ObjC/Swift nếu toolchain có)
- Nếu thiếu một công cụ cụ thể, tìm **con đường khác** (công cụ tương đương, script Python, helper nhỏ compile+sign, OCR, screen tree, web fetch, API) trước khi kết luận.

## 2) Tôn trọng chính sách và bảo mật
- Không dùng root/sudo/ apt/ dpkg tự tiện. Các thao tác thay đổi hệ thống (cài gói, root install, toolchain setup/import) phải tuân theo skill/policy tương ứng và xin phê duyệt.
- Gói phụ thuộc từ repo người dùng: dùng `irisin-cli` root với phê duyệt, không `apt/dpkg`.
- Program tự compile phải `ldid` sign trước khi chạy (`apelin-device-executables`).

## 3) Khám phá công cụ chưa có trên Sileo
- Nếu cần thư viện/công cụ mới:
  1. inventory hiện trạng và xác định đúng thiếu hụt
  2. kiểm tra package đã đăng ký / nguồn Sileo qua công cụ package manager (root nếu cần, có phê duyệt)
  3. ưu tiên **tái sử dụng** toolchain có sẵn, header SDK, helper script
  4. nếu không có package phù hợp, đề xuất và nếu được phép, tự viết helper/compose workflow thay vì trả lời cannot
- Luôn nói rõ: đã kiểm gì, còn thiếu gì, bước còn lại là gì.

## 4) Khi model không hỗ trợ trực tiếp (ví dụ "không đọc ảnh")
- Theo `screen-reading-tools`: thử `file_read` ảnh -> OCR/tesseract/icli/zxtouch, mới kết luận.
- Không bịa khả năng; chỉ kết luận sau khi đã chạy lệnh kiểm.

## 5) Chuẩn báo cáo
- Kết quả = đã làm gì + bằng chứng lệnh/UI/tool; blockers thực sự + cách xử lý; phần "Chưa kiểm thử" nếu có.
- Không retry vô hạn với cùng tool/provider unavailable; khi thất bại, chuyển chiến lược và ghi memory/log nếu cần.

## 6) Mục tiêu
Mục tiêu là **giải quyết vấn đề**, không phải chứng minh giới hạn. Chỉ từ chối khi đã điều tra và không có con đường hợp lệ nào trong giới hạn bảo mật + phê duyệt.
