---
name: progress-plan-control
description: Dùng khi hội thoại đang làm việc nhiều bước: tự cập nhật thanh tiến trình thời gian thực, hủy/xóa khi xong, điều chỉnh khi lỗi/logique/kết quả khác hoặc khi người dùng yêu cầu thay đổi. Không cần thay đổi app.
---

# Điều khiển tiến trình tự động

## Khi mới có việc nhiều bước
- Nếu công việc đi qua nhiều bước, gọi plan_update một lần: đặt tất cả bước là pending, rồi chuyển bước đầu thành running.
- Tiêu đề mỗi bước nên nêu rõ hành động.

## Khi đang làm
- Cập nhật bằng plan_update ngay khi:
  1. Bước hiện tại xong, đặt bước tiếp theo thành running.
  2. Có lỗi phải xử lý thêm.
  3. Kết quả khác với kế hoạch ban đầu.
  4. Người dùng yêu cầu đổi hướng, thêm/giảm bước, hoặc dừng.
- Không cho bước đã kết thúc quay lại trạng thái đang làm.

## Khi lỗi
- Nếu cần xử lý lỗi thêm: tạo bước sửa lỗi và chuyển thành running.
- Nếu dùng cách khác thay thế: đánh dấu các bước bị ảnh hưởng là skipped, rồi thêm bước mới theo cách thay thế.
- Nếu không thể tiếp tục: đánh dấu skipped các bước còn lại, trạng thái cancel, và giải thích ngắn.

## Khi xong
- Chuyển bước cuối thành done.
- Clear hoặc cancel plan nếu công việc kết thúc.
- Không giữ thanh cho việc đã xong nếu người dùng đã thấy xong.

## Quy ước
- Mở/đóng panel là việc của giao diện; logic plan unchanged.
- Luôn ưu tiên yêu cầu người dùng hơn các bước cũ.
- Nếu chỉ hỏi ngắn, không cần lập mới plan.
