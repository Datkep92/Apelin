---
name: zxtouch-device-control
description: Điều khiển thiết bị iOS jailbroken qua ZXTouch (TCP 127.0.0.1:6000): protocol, mã lệnh, touch, toast/alert/switch app, OCR, image match, color, clipboard, recording, và helper Scripts/zxtouch_ctl.py để gọi nhanh.
---

# ZXTouch — điều khiển thiết bị iOS jailbroken

## Tổng quan
- Gói cài: `xyz.cypwn.zxtouch` 0.0.8 (Cydia package).
- Server TCP chạy tại `127.0.0.1:6000` (thường do tweak inject, không cần mở app UI).
- Dùng socket thường; mọi lệnh là text UTF-8 kết thúc `\r\n`.

## Protocol
Format gửi:
```
<task_code><first_data>;;<field2>;;<field3>...;;\r\n
```
- `task_code` là 2 chữ số (10–28).
- **Không có `;;` giữa `task_code` và dữ liệu đầu**; dữ liệu đầu nối trực tiếp sau mã lệnh.
- Các trường sau phân tách bằng `;;`.
- Phản hồi:
  - `0` = thành công.
  - `-1;;<lỗi>` = thất bại.
- Một số lệnh (touch) **không trả response** → không gọi `recv` để tránh treo socket; các lệnh khác thường trả response.

Ví dụ Python đúng:
```python
import socket, time
s = socket.socket(); s.connect(("127.0.0.1", 6000)); time.sleep(0.1)
s.send(b"220;;Hello;;2;;0;;0\r\n")   # toast
print(s.recv(1024))
s.close()
```

## Mã lệnh (tasktypes)
- `10` TASK_PERFORM_TOUCH
- `11` TASK_PROCESS_BRING_FOREGROUND
- `12` TASK_SHOW_ALERT_BOX
- `13` TASK_RUN_SHELL (chạy shell **as root**)
- `14` TASK_TOUCH_RECORDING_START
- `15` TASK_TOUCH_RECORDING_STOP
- `16` TASK_CRAZY_TAP
- `18` TASK_USLEEP
- `19` TASK_PLAY_SCRIPT
- `20` TASK_PLAY_SCRIPT_FORCE_STOP
- `21` TASK_TEMPLATE_MATCH
- `22` TASK_SHOW_TOAST
- `23` TASK_COLOR_PICKER
- `24` TASK_KEYBOARDIMPL
- `25` TASK_GET_DEVICE_INFO
- `26` TASK_TOUCH_INDICATOR
- `27` TASK_TEXT_RECOGNIZER (OCR)
- `28` TASK_COLOR_SEARCHER

## Touch
- Type: `0`=UP, `1`=DOWN, `2`=MOVE.
- Tọa độ nhân 10, zero-pad 5 chữ số (x/y).
- finger_index 2 chữ số (01–19, thường dùng 01).
- Format dữ liệu touch: `<type><finger 2 số><x*10 5 số><y*10 5 số>` (13 ký tự), nối sau `10`.
- Ví dụ touch down tại (562, 1218): `101010562012180` (không recv).

## Thiết bị đã test
- Screen size: `1125x2436` (scale 3).
- Device: iPhone, iOS 16.6, model iPhone10,6.
- Battery: state 1 (unplugged), level thay đổi (~26-35).

## Lệnh thường dùng
- Switch app: `11<bundle_id>` → `11com.apple.springboard`
- Toast: `22<type>;;<content>;;<duration>;;<position>;;<fontSize>` → `223;;text;;2;;0;;0`
- Alert: `12<title>;;<content>;;<duration>` → `12Alert;;Hello;;2`
- Screen size: `251`
- Orientation: `252`
- Scale: `253`
- Device info: `2530`
- Battery: `2531`
- Touch indicator bật/tắt: `261` / `260`
- Keyboard insert text: `241;;<char>` (KEYBOARD_INSERT_TEXT=1) từng ký tự; delete: `244;;1`
- Show/hide keyboard: `242;;2` / `242;;1`
- Paste from clipboard: `245`
- Get clipboard: `246`
- Set clipboard: `247;;<text>`
- Move cursor: `243;;<offset>`
- Color picker: `23<x>;;<y>`
- Color search: `281;;<x>;;<y>;;<w>;;<h>;;rMin;;rMax;;gMin;;gMax;;bMin;;bMax;;skip`
- OCR: `271;;x1,,y1,,w,,h;;custom_words;;min_height;;level;;languages;;correct;;debug_path`
- Image match: `21<template_path>;;max_try;;acceptable;;scale`
- Usleep: `18<microseconds>`
- Recording start/stop: `14` / `15`
- Play script: `19<path>`
- Stop script: `20`
- Run shell root: `13<command>` (nguy hiểm, chỉ dùng khi Sếp yêu cầu rõ).

## Helper nhanh
Sẵn có `Scripts/zxtouch_ctl.py` trong project này. Gọi qua shell:
```
python3 Scripts/zxtouch_ctl.py size
python3 Scripts/zxtouch_ctl.py orientation
python3 Scripts/zxtouch_ctl.py scale
python3 Scripts/zxtouch_ctl.py info
python3 Scripts/zxtouch_ctl.py battery
python3 Scripts/zxtouch_ctl.py toast "Hello" 2
python3 Scripts/zxtouch_ctl.py alert "Title" "Content" 2
python3 Scripts/zxtouch_ctl.py switch com.apple.springboard
python3 Scripts/zxtouch_ctl.py tap 562 1218
python3 Scripts/zxtouch_ctl.py touch-down 562 1218
python3 Scripts/zxtouch_ctl.py touch-up 562 1218
python3 Scripts/zxtouch_ctl.py indicator on
python3 Scripts/zxtouch_ctl.py color 562 1200
python3 Scripts/zxtouch_ctl.py color-search 0 0 100 100
python3 Scripts/zxtouch_ctl.py ocr 0 0 1125 100
python3 Scripts/zxtouch_ctl.py image-match /path/to/template.png
python3 Scripts/zxtouch_ctl.py kb-insert "abc"
python3 Scripts/zxtouch_ctl.py kb-delete 3
python3 Scripts/zxtouch_ctl.py kb-show show
python3 Scripts/zxtouch_ctl.py kb-paste
python3 Scripts/zxtouch_ctl.py kb-get-clip
python3 Scripts/zxtouch_ctl.py kb-set-clip "hello"
python3 Scripts/zxtouch_ctl.py kb-move 3
python3 Scripts/zxtouch_ctl.py record-start
python3 Scripts/zxtouch_ctl.py record-stop
python3 Scripts/zxtouch_ctl.py usleep 1000
python3 Scripts/zxtouch_ctl.py raw "2530" --no-recv
```
Touch commands tự động không recv.

## Lưu ý an toàn
- `TASK_RUN_SHELL` chạy root → chỉ dùng theo yêu cầu rõ ràng của Sếp.
- Touch có thể kích hoạt UI; ưu tiên tọa độ an toàn (status bar, vùng trống) và test nhỏ.
- Touch không trả response; không recv để tránh treo.
- ZXTouch không có auth → chỉ dùng local (127.0.0.1), không expose ra mạng.
- Sau thao tác, chuyển về app cần thiết (ví dụ Apelin) bằng switch_to_app.

## Chưa kiểm chứng trên máy này
- Hiệu ứng crazy tap (`TASK_CRAZY_TAP`) chưa test (có thể treo socket).
- Play script chưa test với file hợp lệ.
- Move cursor chưa test trong text field thực tế.
