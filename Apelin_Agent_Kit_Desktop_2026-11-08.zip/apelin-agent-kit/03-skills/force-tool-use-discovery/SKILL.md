---
name: force-tool-use-discovery
description: Ép buộc model sử dụng công cụ hiện có trước khi từ chối; nếu thiếu, tìm kiếm công cụ/pack/tweak phù hợp với thiết bị iOS 16 rootless dopamine arm64 trên Sileo, GitHub. Áp dụng mọi dự án.
---

# Skill: Ép buộc sử dụng công cụ + khám phá công cụ

## 1. Luật ép buộc
- **Không được** trả lời “không có khả năng” / “không thể” / “model không hỗ trợ” trước khi đã:
  1. Kiểm tra inventory công cụ hiện có (which, command -v, PATH).
  2. Kiểm tra công cụ Apelin đã đăng ký (apelin_toolchain_list, apelin_sdk_list).
  3. Thử các con đường thay thế (Python, Perl, Node, shell, icli, OCR, screen tree, web fetch).
- Chỉ kết luận “không thể” sau khi đã kiểm và không có con đường hợp lệ trong giới hạn bảo mật + phê duyệt.

## 2. Nếu công cụ hiện có không đáp ứng
- **Tìm kiếm trên Sileo/GitHub** cho thiết bị iOS 16 rootless dopamine arm64:
  - Dùng `irisin-cli` (root, có phê duyệt) để kiểm tra package đã cài / nguồn Sileo.
  - Dùng `apelin_web_search` / `apelin_web_fetch` để tìm tweak/pack trên GitHub.
  - Ưu tiên các repo đã biết: GitHub releases, package repositories, tweak repos.
- **Tìm các pack/tweak hỗ trợ**:
  - Liệt kê các package có thể cài (rootless .deb, arm64).
  - Kiểm tra dependencies, conflicts.
  - Đề xuất cài đặt qua `irisin-cli` (root, phê duyệt) hoặc `apelin_package_install` nếu là artifact build.

## 3. Báo cáo
- Luôn nói rõ: đã kiểm gì, còn thiếu gì, bước còn lại là gì.
- Nếu tìm thấy công cụ/pack phù hợp, đề xuất cài đặt và xin phê duyệt.
- Nếu không tìm thấy, báo cáo rõ ràng và đề xuất viết helper nhỏ (compile+sign) hoặc dùng con đường thay thế.

## 4. Giới hạn bảo mật
- Không cài gói tự tiện; phải tuân theo skill `apelin-package-dependencies`.
- Không dùng apt/dpkg; chỉ dùng irisin-cli root với phê duyệt.
- Program tự compile phải ldid sign trước khi chạy.

## 5. Ví dụ kích hoạt
- Người dùng: “Apelin không cho tôi thao tác” → Kiểm tra toolchain, SDK, icli, tìm pack hỗ trợ.
- Người dùng: “Model ko có khả năng” → Kiểm tra khả năng thực tế, tìm công cụ thay thế.
