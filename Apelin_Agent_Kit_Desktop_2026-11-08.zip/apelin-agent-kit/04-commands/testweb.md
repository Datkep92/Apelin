---
name: testweb
description: Tạo trang web thử cho playground/modal kết quả
---

Hãy tạo một trang web HTML nhỏ để test UI web trên app: tiêu đề, nút tăng/giảm, input văn bản, danh sách, màu tương thích dark mode và JavaScript cơ bản. Sau khi tạo, hãy ghi toàn bộ HTML vào file ~/Documents/wiki.qaq.apelin/playground.html để tôi mở bằng Load AI hoặc modal kết quả. Trả lời ngắn gọn.
