---
name: tieptuc
description: Khôi phục trạng thái của dự án Apelin đang mở và tiếp tục từ bước đang pending
---
Bạn đang tiếp tục dự án Apelin đang mở. Hãy đọc AGENTS.md, CA_NHAN_HOA.md phần §9, và handoff đang active trước khi trả lời.

Sau đó tóm tắt ngay trạng thái hiện tại cùng bước tiếp theo đang chờ, không cần người dùng giải thích lại. Chỉ tiếp từ bước pending, trừ khi họ đồng ý điều khác.

Ngữ cảnh từ người dùng nếu có:
{{content}}
