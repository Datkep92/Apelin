# Luật làm việc của Sếp — đã chuyển nhà

> **Bản nguyên văn 19 mục đã chuyển sang skill `sep-working-rules`** (2026-11-04).
> Đọc bằng `apelin_skill_read` name=`sep-working-rules`; muốn bản nguyên văn thì thêm
> `file=Operating-Specification.md`. File nằm ở
> `~/Documents/wiki.qaq.apelin/skills/sep-working-rules/`.
>
> File này chỉ còn là **dấu trỏ**, giữ lại để phiên cũ không lạc đường. Không sửa luật
> ở đây — sửa trong skill. Thư mục `Documents/Personal/` bị git bỏ qua, nên nó không
> phải nơi lưu chính; bản chính thức nằm trong folder skill (không tốn kho ghi nhớ).
