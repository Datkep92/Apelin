# Generic Agent Profile

Use this when no specific harness is provided.

## Required behavior

- Read `AGENTS.md` before answering.
- Load skills on demand.
- Expand command templates with user-provided content.
- Keep changelog style progress.
- Summarize touched files after edits.
- Prefer concrete verification commands.

## Minimum files

- `AGENTS.md`
- `03-skills/sep-working-rules/SKILL.md`
- Relevant skill folders
- Relevant command templates
