# DeepSeek Harness Profile

## Detect

```sh
cd /var/mobile/Documents/dsh 2>/dev/null || cd "$PWD"
npx dsh --version
npx dsh --help
printf 'DSH_HOME=%s\n' "${DSH_HOME:-${HOME}/.dsh}"
find "${DSH_HOME:-${HOME}/.dsh}/profiles" -maxdepth 2 -type f 2>/dev/null | head -50
```

## Inspect active profile

```sh
npx dsh --dump-config
npx dsh --dump-default-config
npx dsh --dump-config-schema
```

## Configure

1. Create a profile (example):

```sh
npx dsh --profile apelin --from-default-profile web
```

2. Place Apelin `AGENTS.md` in the project workspace/profile working directory.
3. Keep Apelin skills in a local directory and expose them through patches if needed.
4. Do not overwrite shipped profile defaults without recording a backup.
5. Test with:

```sh
npx dsh headless "summarize AGENTS.md and list skills"
```

## Verification

- Check `dsh --dump-config` includes expected project/workspace.
- Run one headless task successfully.
