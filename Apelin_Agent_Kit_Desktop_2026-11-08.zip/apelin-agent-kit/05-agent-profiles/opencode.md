# OpenCode Profile

## Detect

```sh
opencode --version 2>&1 || true
opencode --help 2>&1 | head -50
printf 'OPENCODE_CONFIG=%s\n' "$OPENCODE_CONFIG"
```

## Configure

1. Place `AGENTS.md` at repository root.
2. Place skills in the repository when global registration is unknown.
3. Preserve Apelin command template syntax.
4. Read OpenCode config documentation before writing files.
5. Avoid editing generated files without backup.

## Verification

```sh
opencode --help
```

Ask OpenCode to list skills and expand one command template.
