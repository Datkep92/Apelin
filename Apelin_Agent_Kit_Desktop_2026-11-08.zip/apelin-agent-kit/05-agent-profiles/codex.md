# Codex Profile

## Detect

```sh
codex --version
codex --help
printf 'CODEX_HOME=%s\n' "${CODEX_HOME:-}"
find "${CODEX_HOME:-$HOME/.codex}" -maxdepth 3 -type f -name 'config*' 2>/dev/null | head
```

## Configure

1. Put `AGENTS.md` at repository root.
2. Copy Apelin skills into the Codex skill location if supported; otherwise keep them in repo under `.agent/skills`.
3. Keep commands as markdown templates until Codex supports command definitions.
4. Inspect Codex config schema before writing tool-specific configuration.

## Verification

```sh
codex --help
```

Ask Codex to summarize `AGENTS.md` and list nearby skills.
